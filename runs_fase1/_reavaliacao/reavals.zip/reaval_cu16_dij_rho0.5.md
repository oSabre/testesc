| cenario | celula | mesh_lat | ga_delta_mediano | ga_melhores | rs_delta_mediano | rs_melhores | sw_delta | ga_pior_que_mesh | tempo_s |
|---|---|---|---|---|---|---|---|---|---|
| cu16_dij_rho0.5 | bit_reversal_m1.5 | 11064.4 | 3.7 | 0/10 | 4.61 | 0/10 | 9.74 | 10/10 | 28 |
| cu16_dij_rho0.5 | bit_reversal_m2 | 11064.4 | 6.44 | 0/10 | 5.84 | 0/10 | 9.74 | 10/10 | 25 |
| cu16_dij_rho0.5 | bit_reversal_m3 | 11064.4 | 8.82 | 0/10 | 9.3 | 0/10 | 9.74 | 10/10 | 25 |
| cu16_dij_rho0.5 | butterfly_m1.5 | 11597.1 | -2.15 | 3/10 | -1.68 | 1/10 | 5.46 | 0/10 | 29 |
| cu16_dij_rho0.5 | butterfly_m2 | 11597.1 | 1.3 | 0/10 | 1.21 | 0/10 | 5.46 | 0/10 | 25 |
| cu16_dij_rho0.5 | butterfly_m3 | 11597.1 | 3.99 | 0/10 | 3.75 | 0/10 | 5.46 | 10/10 | 25 |
| cu16_dij_rho0.5 | uniform_m1.5 | 11102.9 | 5.63 | 0/10 | 4.87 | 0/10 | 8.7 | 10/10 | 29 |
| cu16_dij_rho0.5 | uniform_m2 | 11102.9 | 8.84 | 0/10 | 8.45 | 0/10 | 8.7 | 10/10 | 25 |
| cu16_dij_rho0.5 | uniform_m3 | 11102.9 | 11.56 | 0/10 | 11.69 | 0/10 | 8.7 | 10/10 | 25 |
