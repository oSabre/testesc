| cenario | celula | mesh_lat | ga_delta_mediano | ga_melhores | rs_delta_mediano | rs_melhores | sw_delta | ga_pior_que_mesh | tempo_s |
|---|---|---|---|---|---|---|---|---|---|
| cu8_bfs_rho0.5 | bit_reversal_m1.5 | 8118.5 | -19.22 | 10/10 | -14.89 | 10/10 | -9.46 | 0/10 | 32 |
| cu8_bfs_rho0.5 | bit_reversal_m2 | 8118.5 | -23.7 | 10/10 | -18.88 | 10/10 | -9.46 | 0/10 | 22 |
| cu8_bfs_rho0.5 | bit_reversal_m3 | 8118.5 | -25.2 | 10/10 | -23.32 | 10/10 | -9.46 | 0/10 | 22 |
| cu8_bfs_rho0.5 | butterfly_m1.5 | 7592.8 | -16.01 | 10/10 | -11.66 | 10/10 | -1.9 | 0/10 | 26 |
| cu8_bfs_rho0.5 | butterfly_m2 | 7592.8 | -19.37 | 10/10 | -14.95 | 10/10 | -1.9 | 0/10 | 22 |
| cu8_bfs_rho0.5 | butterfly_m3 | 7592.8 | -20.61 | 10/10 | -18.38 | 10/10 | -1.9 | 0/10 | 22 |
| cu8_bfs_rho0.5 | uniform_m1.5 | 6898.9 | 0.09 | 0/10 | 1.24 | 0/10 | -0.54 | 0/10 | 26 |
| cu8_bfs_rho0.5 | uniform_m2 | 6898.9 | -2.0 | 0/10 | -0.94 | 0/10 | -0.54 | 0/10 | 23 |
| cu8_bfs_rho0.5 | uniform_m3 | 6898.9 | -3.35 | 1/10 | -3.35 | 2/10 | -0.54 | 0/10 | 23 |
