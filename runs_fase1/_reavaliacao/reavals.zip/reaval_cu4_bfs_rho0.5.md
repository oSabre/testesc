| cenario | celula | mesh_lat | ga_delta_mediano | ga_melhores | rs_delta_mediano | rs_melhores | sw_delta | ga_pior_que_mesh | tempo_s |
|---|---|---|---|---|---|---|---|---|---|
| cu4_bfs_rho0.5 | bit_reversal_m1.5 | 9062.2 | -14.14 | 10/10 | -10.53 | 10/10 | -5.99 | 0/10 | 39 |
| cu4_bfs_rho0.5 | bit_reversal_m2 | 9062.2 | -18.23 | 10/10 | -15.27 | 10/10 | -5.99 | 0/10 | 34 |
| cu4_bfs_rho0.5 | bit_reversal_m3 | 9062.2 | -19.97 | 10/10 | -18.54 | 10/10 | -5.99 | 0/10 | 34 |
| cu4_bfs_rho0.5 | butterfly_m1.5 | 8926.6 | -15.22 | 10/10 | -11.45 | 10/10 | -1.33 | 0/10 | 39 |
| cu4_bfs_rho0.5 | butterfly_m2 | 8926.6 | -18.37 | 10/10 | -14.06 | 10/10 | -1.33 | 0/10 | 34 |
| cu4_bfs_rho0.5 | butterfly_m3 | 8926.6 | -19.66 | 10/10 | -17.73 | 10/10 | -1.33 | 0/10 | 34 |
| cu4_bfs_rho0.5 | uniform_m1.5 | 8130.5 | -0.6 | 0/10 | -0.62 | 0/10 | -2.19 | 0/10 | 39 |
| cu4_bfs_rho0.5 | uniform_m2 | 8130.5 | -2.63 | 0/10 | -1.75 | 0/10 | -2.19 | 0/10 | 34 |
| cu4_bfs_rho0.5 | uniform_m3 | 8130.5 | -3.77 | 2/10 | -3.43 | 2/10 | -2.19 | 0/10 | 36 |
